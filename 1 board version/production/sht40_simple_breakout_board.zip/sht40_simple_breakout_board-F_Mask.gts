G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.1*
G04 #@! TF.CreationDate,2026-11-01T13:43:08+01:00*
G04 #@! TF.ProjectId,sht40_simple_breakout_board,73687434-305f-4736-996d-706c655f6272,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.1) date 2026-11-01 13:43:08*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.237500X-0.237500X0.300000X-0.237500X-0.300000X0.237500X-0.300000X0.237500X0.300000X0*%
%ADD11R,0.300000X0.500000*%
%ADD12RoundRect,0.237500X0.237500X-0.250000X0.237500X0.250000X-0.237500X0.250000X-0.237500X-0.250000X0*%
%ADD13C,1.700000*%
%ADD14R,1.700000X1.700000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,C1*
X153670000Y-86737500D03*
X153670000Y-88462500D03*
G04 #@! TD*
D11*
G04 #@! TO.C,U1*
X157470000Y-87700000D03*
X158270000Y-87700000D03*
X158270000Y-86300000D03*
X157470000Y-86300000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,R2*
X152970000Y-92412500D03*
X152970000Y-90587500D03*
G04 #@! TD*
G04 #@! TO.C,R1*
X155270000Y-92412500D03*
X155270000Y-90587500D03*
G04 #@! TD*
D13*
G04 #@! TO.C,J1*
X147570000Y-89200000D03*
X147570000Y-91740000D03*
X147570000Y-94280000D03*
D14*
X147570000Y-86660000D03*
G04 #@! TD*
M02*
